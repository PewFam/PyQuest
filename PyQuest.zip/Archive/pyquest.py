import request.requests

header ="""
\033[5m
   ___       ____               __ 
  / _ \__ __/ __ \__ _____ ___ / /_
 / ___/ // / /_/ / // / -_|_-</ __/
/_/   \_, /\___\_\_,_/\__/___/\__/ 
     /___/                         

\033[0m                                             
"""
from os import name, system 
if name == "nt":
	system("cls")
elif name == "posix":
	system("clear")
	
print(header)

url = input("\n\033[1mURL : \033[0m")

r = requests.get(url)

list = input("""
what ?

1 - headers
2 - text
3 - nothing


""")
if list == "1":
	print(r.headers)
elif list == "2":
	print(r.text)
elif list == "3":
	pass
	
